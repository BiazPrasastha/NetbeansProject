/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kendaraan;

/**
 *
 * @author biazprasastha
 */
public interface Pribadi {
    public String BBM = "Tergantung Duit";
    public int jmlKursi = 4;
    public int jmlRoda = 4;
    public int jmlPintu = 4;
    public void tampilData();
}
