/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kendaraan;

/**
 *
 * @author biazprasastha
 */
public interface Sport {
    public String BBM = "Pertalite Turbo";
    public int jmlKursi = 2;
    public int jmlRoda = 4;
    public int jmlPintu = 2;
    public void tampilData();
    
    
}
